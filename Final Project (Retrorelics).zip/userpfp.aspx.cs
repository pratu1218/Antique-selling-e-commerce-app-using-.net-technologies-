﻿using System;
using System.Data.SqlClient;
using System.Web.UI;

namespace WebApplication2
{
    public partial class userpfp : Page
    {
        private string connectionString = "Server=Pratik\\SQLEXPRESS;Database=AuctionApk;Trusted_Connection=True;";
        private string loggedInUsername;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["username"] != null)
                {
                    loggedInUsername = Session["username"].ToString();
                    lblUsername.Text = loggedInUsername;
                }
                else
                {
                    Response.Redirect("LoginForm.aspx");
                }
            }
        }

        protected void btnMyCollection_Click(object sender, EventArgs e)
        {
            Response.Redirect("Collection.aspx");
        }

        protected void btnTransactionHistory_Click(object sender, EventArgs e)
        {
            Response.Redirect("TransactionHistory.aspx");
        }

        protected void btnHelpSupport_Click(object sender, EventArgs e)
        {
            Response.Redirect("HelpSupport.aspx");
        }
    }
}

﻿using System;
using System.Data.SqlClient;
using System.Web;

namespace WebApplication2
{
    public partial class ThankYou : System.Web.UI.Page
    {
        private string connString = "Server=Pratik\\SQLEXPRESS;Database=AuctionApk;Trusted_Connection=True;";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string productName = Request.QueryString["ProductName"];
                string price = Request.QueryString["Price"];
                string userName = Session["UserName"] != null ? Session["UserName"].ToString() : "Guest";
                string deliveryAddress = Session["DeliveryAddress"] != null ? Session["DeliveryAddress"].ToString() : "Unknown";

               /* if (string.IsNullOrEmpty(productName) || string.IsNullOrEmpty(price))
                {
                    lblProductName.Text = "Unknown Product";
                    lblPrice.Text = "N/A";
                    lblDeliveryDate.Text = "Delivery Date Unavailable";
                    return;
                }*/

                // Generate a fake delivery date (2 to 10 days ahead)
                Random rand = new Random();
                int daysToAdd = rand.Next(2, 11);
                DateTime deliveryDate = DateTime.Now.AddDays(daysToAdd);

                // Display details
                lblProductName.Text = Server.HtmlEncode(productName);
                lblPrice.Text = "₹" + Server.HtmlEncode(price);
                lblDeliveryDate.Text = deliveryDate.ToString("dddd, dd MMMM yyyy");

                // ✅ Add payment details with duplicate prevention
                AddToPaymentHistory(productName, price, userName, deliveryAddress);
            }
        }

        private void AddToPaymentHistory(string productName, string price, string userName, string deliveryAddress)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connString))
                {
                    con.Open();

                    // ✅ Check if the payment record already exists before inserting
                    string checkQuery = @"
                        SELECT COUNT(1) FROM Payments 
                        WHERE ProductName = @ProductName AND Amount = @Amount 
                        AND UserName = @UserName AND DeliveryAddress = @DeliveryAddress";

                    using (SqlCommand checkCmd = new SqlCommand(checkQuery, con))
                    {
                        checkCmd.Parameters.AddWithValue("@ProductName", productName);
                        checkCmd.Parameters.AddWithValue("@Amount", Convert.ToDecimal(price));
                        checkCmd.Parameters.AddWithValue("@UserName", userName);
                        checkCmd.Parameters.AddWithValue("@DeliveryAddress", deliveryAddress);

                        int exists = Convert.ToInt32(checkCmd.ExecuteScalar());

                        if (exists > 0)
                        {
                            // If record already exists, skip insertion
                            return;
                        }
                    }

                    // ✅ If no existing record, insert new payment record
                    string insertQuery = @"
                        INSERT INTO Payments (ProductName, Amount, PaymentDate, UserName, DeliveryAddress, PaymentStatus) 
                        VALUES (@ProductName, @Amount, GETDATE(), @UserName, @DeliveryAddress, 'Completed')";

                    using (SqlCommand insertCmd = new SqlCommand(insertQuery, con))
                    {
                        insertCmd.Parameters.AddWithValue("@ProductName", productName);
                        insertCmd.Parameters.AddWithValue("@Amount", Convert.ToDecimal(price));
                        insertCmd.Parameters.AddWithValue("@UserName", userName);
                        insertCmd.Parameters.AddWithValue("@DeliveryAddress", deliveryAddress);

                        insertCmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write($"<script>alert('Database Error: {ex.Message}');</script>");
            }
        }
    }
}

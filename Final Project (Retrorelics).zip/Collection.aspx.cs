﻿using System;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class Collection : Page
    {
        private string connString = "Server=Pratik\\SQLEXPRESS;Database=AuctionApk;Trusted_Connection=True;";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadItems();
            }
        }

        private void LoadItems()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();

                    // Fetch only items that are NOT in the Payments table (i.e., unsold items)
                    string query = @"
                SELECT Name, Price, Description, Image 
                FROM Collections 
                WHERE Name NOT IN (SELECT ProductName FROM Payments)";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                AddItemToPage(reader);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write($"<script>alert('Error: {ex.Message}');</script>");
            }
        }


        private void AddItemToPage(SqlDataReader reader)
        {
            Panel itemPanel = new Panel { CssClass = "item-container" };

            Image img = new Image { CssClass = "item-image" };
            if (!reader.IsDBNull(reader.GetOrdinal("Image")))
            {
                byte[] imageBytes = (byte[])reader["Image"];
                string base64String = Convert.ToBase64String(imageBytes);
                img.ImageUrl = "data:image/png;base64," + base64String;
            }
            else
            {
                img.ImageUrl = "images/default.png";
            }

            string name = reader["Name"].ToString();
            string price = reader["Price"].ToString();

            Label lblName = new Label { Text = $"<h3>{HttpUtility.HtmlEncode(name)}</h3>" };
            Label lblPrice = new Label { Text = $"<p>Price: ₹{price}</p>" };
            Label lblDescription = new Label { Text = $"<p>{reader["Description"]}</p>" };

            Button btnBuy = new Button
            {
                Text = "Buy",
                CssClass = "btn-buy"
            };

            // ✅ Now passing both name and price
            btnBuy.Attributes["OnClick"] = $"window.location='Payment.aspx?name={HttpUtility.UrlEncode(name)}&price={HttpUtility.UrlEncode(price)}'; return false;";

            itemPanel.Controls.Add(img);
            itemPanel.Controls.Add(lblName);
            itemPanel.Controls.Add(lblPrice);
            itemPanel.Controls.Add(lblDescription);
            itemPanel.Controls.Add(btnBuy);

            collectionPanel.Controls.Add(itemPanel);
        }
    }
}

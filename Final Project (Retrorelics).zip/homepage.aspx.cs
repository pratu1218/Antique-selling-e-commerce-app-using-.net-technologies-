﻿using System;
using System.Web.UI;

namespace WebApplication2
{
    public partial class homepage : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        
        }


        protected void btnQR_Click(object sender, EventArgs e)
        {
            Response.Redirect("QRForm.aspx");
        }

        protected void btnProfile_Click(object sender, EventArgs e)
        {
            Response.Redirect("userpfp.aspx");
        }
    }
}

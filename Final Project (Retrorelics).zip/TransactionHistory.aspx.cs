﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class TransactionHistory : System.Web.UI.Page
    {
        private string connString = "Server=Pratik\\SQLEXPRESS;Database=AuctionApk;Trusted_Connection=True;";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadTransactionHistory();
            }
        }

        private void LoadTransactionHistory()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    string userName = Session["UserName"] != null ? Session["UserName"].ToString() : "Guest";

                    // Ensure unique transactions by using DISTINCT and grouping data
                    string query = @"
                        SELECT MIN(PaymentID) AS PaymentID, UserName, ProductName, Amount, PaymentDate, DeliveryAddress
                        FROM Payments 
                        WHERE UserName = @UserName 
                        GROUP BY UserName, ProductName, Amount, PaymentDate, DeliveryAddress
                        ORDER BY PaymentDate DESC";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@UserName", userName);
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);

                        gvTransactionHistory.DataSource = dt;
                        gvTransactionHistory.DataBind();
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write($"<script>alert('Error: {ex.Message}');</script>");
            }
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("userpfp.aspx"); // Redirect to user profile page
        }
    }
}

﻿using System;
using System.Data.SqlClient;
using System.Web.UI;

namespace WebApplication2
{
    public partial class Registration : Page
    {
        private string connectionString = "Server=Pratik\\SQLEXPRESS;Database=AuctionApk;Trusted_Connection=True;";

        protected void Page_Load(object sender, EventArgs e)
        {
        }

        // Auto-calculate Age when DOB is entered
        protected void txtDOB_TextChanged(object sender, EventArgs e)
        {
            if (DateTime.TryParse(txtDOB.Text, out DateTime dob))
            {
                int age = DateTime.Now.Year - dob.Year;
                if (dob > DateTime.Now.AddYears(-age)) // Adjust for leap years
                {
                    age--;
                }
                txtAge.Text = age.ToString();
            }
            else
            {
                txtAge.Text = "";
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtFullName.Text) ||
                string.IsNullOrWhiteSpace(txtDOB.Text) ||
                string.IsNullOrWhiteSpace(txtAge.Text) ||
                string.IsNullOrWhiteSpace(txtUsername.Text) ||
                string.IsNullOrWhiteSpace(txtPassword.Text) ||
                string.IsNullOrWhiteSpace(txtConfirmPassword.Text))
            {
                lblMessage.ForeColor = System.Drawing.Color.Red;
                lblMessage.Text = "⚠ All fields are required!";
                return;
            }

            if (txtPassword.Text != txtConfirmPassword.Text)
            {
                lblMessage.ForeColor = System.Drawing.Color.Red;
                lblMessage.Text = "⚠ Passwords do not match!";
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                // ✅ Check if username already exists
                string checkUserQuery = "SELECT COUNT(*) FROM regidetail WHERE username = @username";
                using (SqlCommand cmd = new SqlCommand(checkUserQuery, conn))
                {
                    cmd.Parameters.AddWithValue("@username", txtUsername.Text);
                    int count = (int)cmd.ExecuteScalar();

                    if (count > 0)
                    {
                        lblMessage.ForeColor = System.Drawing.Color.Red;
                        lblMessage.Text = "⚠ Username already exists! Choose a different one.";
                        return;
                    }
                }

                // ✅ Insert new user into the database
                string insertQuery = "INSERT INTO regidetail (name, date_of_birth, age, username, password) VALUES (@name, @dob, @age, @username, @password)";
                using (SqlCommand cmd = new SqlCommand(insertQuery, conn))
                {
                    cmd.Parameters.AddWithValue("@name", txtFullName.Text);
                    cmd.Parameters.AddWithValue("@dob", txtDOB.Text);
                    cmd.Parameters.AddWithValue("@age", txtAge.Text);
                    cmd.Parameters.AddWithValue("@username", txtUsername.Text);
                    cmd.Parameters.AddWithValue("@password", txtPassword.Text); // ⚠ Hash passwords in real applications

                    cmd.ExecuteNonQuery();
                }
            }

            // ✅ Clear form after successful registration
            txtFullName.Text = "";
            txtDOB.Text = "";
            txtAge.Text = "";
            txtUsername.Text = "";
            txtPassword.Text = "";
            txtConfirmPassword.Text = "";

            lblMessage.ForeColor = System.Drawing.Color.Green;
            lblMessage.Text = "✔ Registration Successful! Redirecting to login...";

            // ✅ Redirect to Login Page after 2 seconds
            Response.AppendHeader("Refresh", "2;url=LoginForm.aspx");
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            txtFullName.Text = "";
            txtDOB.Text = "";
            txtAge.Text = "";
            txtUsername.Text = "";
            txtPassword.Text = "";
            txtConfirmPassword.Text = "";
            lblMessage.Text = "";
        }
    }
}

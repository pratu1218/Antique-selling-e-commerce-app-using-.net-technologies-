﻿using System;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;

namespace WebApplication2
{
    public partial class Payment : Page
    {
        private string connString = "Server=Pratik\\SQLEXPRESS;Database=AuctionApk;Trusted_Connection=True;";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string name = Request.QueryString["name"];
                string price = Request.QueryString["price"];

                if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(price))
                {
                    lblItemDetails.Text = "<p style='color: red;'>Error: Item details missing!</p>";
                    return;
                }

                name = HttpUtility.UrlDecode(name);
                price = HttpUtility.UrlDecode(price);

                LoadItemDetails(name, price);
            }
        }

        private void LoadItemDetails(string name, string price)
        {
            lblItemDetails.Text = $@"
                <div class='item-card'>
                    <h3>{HttpUtility.HtmlEncode(name)}</h3>
                    <p>Price: ₹{HttpUtility.HtmlEncode(price)}</p>
                </div>";
        }

        protected void BtnConfirm_Click(object sender, EventArgs e)
        {
            string name = Request.QueryString["name"];
            string price = Request.QueryString["price"];

            if (!string.IsNullOrEmpty(name) && !string.IsNullOrEmpty(price))
            {
                Response.Redirect($"PaymentProcessing.aspx?ProductName={HttpUtility.UrlEncode(name)}&price={HttpUtility.UrlEncode(price)}");
            }
            else
            {
                lblItemDetails.Text = "<p style='color: red;'>Error: Missing product details.</p>";
            }
        }
    }
}

﻿using System;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;

namespace WebApplication2
{
    public partial class PaymentProcessing : Page
    {
        private string connString = "Server=Pratik\\SQLEXPRESS;Database=AuctionApk;Trusted_Connection=True;";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string productName = Request.QueryString["ProductName"];
                string price = Request.QueryString["price"];

                if (string.IsNullOrEmpty(productName) || string.IsNullOrEmpty(price))
                {
                    lblOrderDetails.Text = "<p class='error'>Error: Order details missing!</p>";
                    return;
                }

                productName = HttpUtility.UrlDecode(productName);
                price = HttpUtility.UrlDecode(price);

                lblOrderDetails.Text = $"<h3>Order: {HttpUtility.HtmlEncode(productName)}</h3><p>Amount: ₹{HttpUtility.HtmlEncode(price)}</p>";
            }
        }

        protected void btnPay_Click(object sender, EventArgs e)
        {
            btnPay.Enabled = false; // Prevent double click

            string cardNumber = txtCardNumber.Text.Trim();
            string expiry = txtExpiry.Text.Trim();
            string cvv = txtCVV.Text.Trim();
            string productName = Request.QueryString["ProductName"];
            string price = Request.QueryString["price"];
            string address = Request.Form["txtAddress"]?.Trim();
            if (string.IsNullOrEmpty(address)) address = "Unknown";

            string userName = Session["UserName"] != null ? Session["UserName"].ToString().ToLower() : "guest";

            if (string.IsNullOrEmpty(cardNumber) || string.IsNullOrEmpty(expiry) || string.IsNullOrEmpty(cvv) || string.IsNullOrEmpty(address))
            {
                lblMessage.Text = "⚠ Please fill in all payment details and enter a valid address.";
                btnPay.Enabled = true;
                return;
            }

            try
            {
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();

                    // Check for duplicate payment
                    string checkQuery = "SELECT COUNT(*) FROM Payments WHERE ProductName = @ProductName";
                    using (SqlCommand checkCmd = new SqlCommand(checkQuery, conn))
                    {
                        checkCmd.Parameters.AddWithValue("@ProductName", productName);
                        int existingCount = (int)checkCmd.ExecuteScalar();

                        lblMessage.Text += $"<br>DEBUG: Existing Count = {existingCount}";

                        if (existingCount > 0)
                        {
                            lblMessage.Text += "<br>⚠ Error: This product has already been purchased!";
                            btnPay.Enabled = true;
                            return;
                        }
                    }

                    // Insert payment record
                    string query = "INSERT INTO Payments (ProductName, Amount, PaymentDate, UserName, DeliveryAddress) VALUES (@ProductName, @Price, GETDATE(), @UserName, @DeliveryAddress)";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@ProductName", productName);
                        cmd.Parameters.AddWithValue("@Price", Convert.ToDecimal(price));
                        cmd.Parameters.AddWithValue("@UserName", userName);
                        cmd.Parameters.AddWithValue("@DeliveryAddress", address);
                        cmd.ExecuteNonQuery();
                    }
                }

                // Redirect after successful payment
                Response.Redirect("ThankYou.aspx", false);
                Context.ApplicationInstance.CompleteRequest();
            }
            catch (Exception ex)
            {
                lblMessage.Text = $"<p style='color: red;'>⚠ Error processing payment: {ex.Message}</p>";
                btnPay.Enabled = true;
            }
        }

        protected void btnViewHistory_Click(object sender, EventArgs e)
        {
            Response.Redirect("TransactionHistory.aspx");
        }
        protected void btnQRPay_Click(object sender, EventArgs e)
        {
            Response.Redirect("QRForm.aspx");
        }
    }
}

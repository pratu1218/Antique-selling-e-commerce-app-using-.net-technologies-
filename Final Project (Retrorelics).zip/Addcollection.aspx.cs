﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
	public partial class Addcollection : System.Web.UI.Page
	{
        private string connString = "Server=Pratik\\SQLEXPRESS;Database=AuctionApk;Trusted_Connection=True;";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadCollectionData();
            }
        }

        private void LoadCollectionData()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "SELECT ItemID, Name, Price, Description, Image FROM Collections";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    try
                    {
                        conn.Open();
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);


                    }
                    catch (Exception ex)
                    {
                        Response.Write("<script>alert('Error: " + ex.Message + "');</script>");
                    }
                }
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;
            decimal price;

            if (!decimal.TryParse(txtPrice.Text, out price))
            {
                Response.Write("<script>alert('Invalid price format!');</script>");
                return;
            }

            string description = txtDescription.Text;
            byte[] imageBytes = null;

            if (fileUpload.HasFile)
            {
                using (BinaryReader br = new BinaryReader(fileUpload.PostedFile.InputStream))
                {
                    imageBytes = br.ReadBytes(fileUpload.PostedFile.ContentLength);
                }
            }

            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "INSERT INTO Collections (Name, Price, Description, Image) VALUES (@Name, @Price, @Description, @Image)";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Name", name);
                    cmd.Parameters.AddWithValue("@Price", price);
                    cmd.Parameters.AddWithValue("@Description", description);
                    cmd.Parameters.AddWithValue("@Image", (object)imageBytes ?? DBNull.Value);

                    try
                    {
                        conn.Open();
                        cmd.ExecuteNonQuery();

                        // Show success message without refreshing the list
                        Response.Write("<script>alert('Item added successfully!');</script>");

                        // Clear input fields after submission
                        txtName.Text = "";
                        txtPrice.Text = "";
                        txtDescription.Text = "";
                    }
                    catch (Exception ex)
                    {
                        Response.Write("<script>alert('Error: " + ex.Message + "');</script>");
                    }
                }
            }
        }
    }
}